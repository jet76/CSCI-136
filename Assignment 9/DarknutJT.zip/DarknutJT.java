// Name        : Joe Turner
// Username    : jeturner
// Description : See "Description" variable below.

import java.awt.Dimension;
import java.awt.Point;

public class DarknutJT extends Creature
{
    // Instance variables
    private final String AuthorName = "Joe Turner"; // required by darwin
    private final String Description = "Inspired by the 'Darknut' enemies from The Legend of Zelda, which are known to charge at their enemies."; // required by darwin
    private static String[][] map; // 2D array for map
    
    @Override
    public void run()
    {
        // if the map hasn't been constructed, call the constructor
        if (map == null) setMap(getMapDimensions());
        // loop while alive
        while (true)
        {
            Observation[] obs = observe(); // observe            
            mapObservation(obs); // map observation         
            if (isEnemy(obs[0])) charge(obs[0]); // charge an observed enemy
            else if (obs[0].classId == FLYTRAP_CLASS_ID) charge(obs[0]); // charge fly-traps
            else if (obs[obs.length - 2].type == Type.CREATURE) turnLeft(); // avoid friendly creatures by turning
            explore(getPosition()); // explore
        }        
    }

    // accepts a single observation, attempts a charge to the observation.
    // if the charge is successful the observation will be attacked.
    private void charge(Observation observation)
    {
        boolean attack = true; // variable to determine attack
        // attempt to charge the enemy
        for (int i = 0; i < distance(observation.position) - 1; i++)
        {
            // if something gets in the way, stop and don't attack
            if (!moveForward())
            {
                attack = false;
                break;
            }    
        }
        // attack if the charge succeeded
        if (attack) attack();
    }

    // Checks the map cells to the N, S, E & W of the creature
    // then explores the creatures movement options
    private void explore(Point p)
    {
        // get creature's current map coordinates
        int x = (int) p.getX();
        int y = (int) p.getY();
        // check map cells adjacent to the creature
        String n = map[y-1][x];
        String s = map[y+1][x];
        String e = map[y][x+1];
        String w = map[y][x-1];
        // use creature's direction and mapped cells to determine move
        switch(getDirection())
        {
            case EAST:
                move(e, n, s, w);                    
                break;
            case NORTH:
                move(n, w, e, s);
                break;
            case SOUTH:
                move(s, e, w, n);
                break;                    
            case WEST:
                move(w, s, n, e);
                break;
            default:
                break;
        }
    }

    // Examines map cells surrounding the creature and turns or moves the
    // creature in the direction of the next unexplored or empty cell
    private void move(String f, String l, String r, String b)
    {
        // make a random turn if both sides unexplored
        if ((l.equals("U") && r.equals("U"))) randomTurn();
        // turn left if side unexplored
        else if (l.equals("U")) turnLeft();
        // turn right if side unexplored
        else if (r.equals("U")) turnRight();
        // turn around if unexplored
        else if (b.equals("U")) turnAround();
        // move forward if empty or unexplored
        else if (f.equals("E") || f.equals("U")) moveForward();
        // turn left if empty
        else if (l.equals("E")) turnLeft();
        // turn right if empty
        else if (r.equals("E")) turnRight();
        // dead end! turn around!
        else turnAround();
    }

    // Create map with boundaries and initial markings for the map
    private void setMap(Dimension d)
    {
        int w = (int) d.getWidth(); // get width
        int h = (int) d.getHeight(); // get height 
        map = new String[h][w]; // create the map
        // loop through all the cells of the map
        for (int i = 0; i < h; i++)
        {
            for (int j = 0; j < w; j++)
            {
                // if the cell is on the outer edges it's a wall (boundary)
                if (i == 0 || i == h - 1 || j == 0 || j == w - 1) map[i][j] = "W";
                // otherwise it's unexplored at this point
                else map[i][j] = "U";
            }
        }
    }

    // Unused method for displaying the map
    @SuppressWarnings("unused")
    private void printMap()
    {
        System.out.println("\nMap:");
        for (int i = 0; i < map.length; i++)
        {
            for (int j = 0; j < map[0].length; j++)
            {
                System.out.print(map[i][j] + " ");
            }
            System.out.println();
        }
    }

    // add observations to the map
    private void mapObservation(Observation[] obs) 
    {
        // for each cell observed
        for (Observation o : obs)
        {
            // get info about the observed cell
            Point p = o.position; // get point
            int x = (int) p.getX(); // get x coordinate
            int y = (int) p.getY(); // get y coordinate
            String c = map[y][x]; // get the marking on the map
            // if the cell is unexplored
            if (c.equals("U"))
            {
                // check the observation type and mark the map
                switch(o.type)
                {
                    case CREATURE:
                        if (isEnemy(o)) map[y][x] = "!"; 
                        else if (o.classId == FLYTRAP_CLASS_ID) map[y][x] = "F";
                        else if (o.classId == APPLE_CLASS_ID) map[y][x] = "A";
                        else map[y][x] = "@";                            
                        break;
                    case EMPTY:
                        map[y][x] = "E";
                        break;
                    case HAZARD:
                        map[y][x] = "H";
                        break;
                    case WALL:
                        map[y][x] = "W";
                        break;
                    default:
                        break;
                }
            }
        }
    }

    // Turns the creature in a random direction
    private void randomTurn()
    {
        double d = Math.random(); // get a random number
        if (d < 0.5) turnLeft(); // turn left on low
        else turnRight(); // turn right on high
    }

    // Turns the creature around
    private void turnAround()
    {
        turnLeft();
        turnLeft();
    }

    @Override
    public String getAuthorName() { return AuthorName; }

    @Override
    public String getDescription() { return Description; }   

}
