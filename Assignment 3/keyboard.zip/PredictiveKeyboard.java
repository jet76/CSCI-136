/*************************************************************************
 * Name        : 
 * Username    : 
 * Description :  
 *************************************************************************/

import java.awt.Font;

public class PredictiveKeyboard 
{	
	public static void main(String [] args)
	{
	}
}
