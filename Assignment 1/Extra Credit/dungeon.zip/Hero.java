// Name        :
// Username    :
// Description :

public class Hero
{
	// TBD: instance variables
	
	/**
	 * Create a new Hero object
	 * 
	 * @param cellX     Starting cell x-position
	 * @param cellY     Starting cell y-position
	 * @param tileSize  Size of image tiles in pixels
	 * @param image     Image filename for the Hero
	 */
	public Hero(int cellX, int cellY, int tileSize, String image)
	{
		// TBD
	}

	/**
	 * Draw the Hero at its current location  
	 */
	public void draw()
	{
		// TBD
	}
	
	/**
	 * Called when Hero uses a key to open a door 
	 */
	public void useKey()
	{
		// TBD
	}
	
	/**
	 * Find out how many keys the Hero has left
	 * 
	 * @return  Number of keys
	 */
	public int getNumKeys()
	{
		// TBD
		return 0;
	}
	
	/**
	 * Called when the Hero takes a key 
	 */
	public void takeKey()
	{
		// TBD
	}

	/**
	 * Called when the Hero takes a gem 
	 */
	public void takeGem() 
	{
		// TBD
	}
	
	/**
	 * Move the Hero based on the key hit by the user:
	 * 'w' = move north
	 * 's' = move south
	 * 'a' = move west
	 * 'd' = move east
	 * 
	 * @param ch       Character typed by the player
	 * @param dungeon  Reference to the Dungeon object
	 */
	public void move(char ch, Dungeon dungeon)
	{
		// TBD
	}

	/**
	 * Test out some of the methods in the Hero class
	 */
	public static void main(String [] args)
	{
		// Fake a dungeon that is 6 x 3, assume 32 pixel tiles
		final int TILE_SIZE = 32;		
		StdDraw.setCanvasSize(6 * TILE_SIZE, 3 * TILE_SIZE);
		StdDraw.setXscale(0, 6 * TILE_SIZE);
		StdDraw.setYscale(0, 3 * TILE_SIZE);
		
		// Create a boy hero at (1, 1)
		Hero hero1 = new Hero(1, 1, TILE_SIZE, "boy.png");
		hero1.draw();
		hero1.takeGem();
		hero1.takeGem();
		hero1.takeKey();
		hero1.useKey();
		
		// Create a girl hero at (5, 2)
		Hero hero2 = new Hero(5, 2, TILE_SIZE, "girl.png");
		hero2.draw();		
	}
	
}
