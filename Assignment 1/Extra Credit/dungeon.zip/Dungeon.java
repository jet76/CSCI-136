// Name        :
// Username    :
// Description :

public class Dungeon
{
	// TBD: instance variables
	
	/**
	 * Construct a new dungeon of the specified size.
	 * The dungeon starts out completely empty.
	 * Creator must later call set() to initialize each Cell.
	 * 
	 * @param width     How many cells wide the dungeon is
	 * @param height    How many cells tall the dungeon is
	 * @param tileSize  Size of tiles in pixels
	 */
	public Dungeon(int width, int height, int tileSize)
	{
		// TBD
	}
		
	/**
	 * Setup a given grid location based on a string
	 * that represents the type of thing at location.
	 * 
	 * "W" = wall, image "dirt.png"
	 * "S" = secret passage, image "stone.png"
	 * "D" = door, image "door_closed.png", "door_open.png"
	 * "-" = dirt floor, image "stone.png"
	 * 
	 * @param cellX  x index of the cell 
	 * @param cellY  y index of the cell
	 * @param str    letter code from the dungeon file
	 */
	public void set(int cellX, int cellY, String str)
	{
		// TBD
	}
	
	/**
	 * Add a key to a random location in the dungeon.
	 * The location must be valid, that it it should not
	 * be a wall, a door, already have a key or gem, or
	 * be the hero's starting location.
	 */
	public void addKey()
	{
		// TBD
	}
	
	/**
	 * Add a gem to a random location in the dungeon.
	 * The location must be valid, that it it should not
	 * be a wall, a door, already have a key or gem, or
	 * be the hero's starting location.
	 */
	public void addGem()
	{
		// TBD
	}

	/**
	 * Attempt to move the hero to the given cell location.
	 * 
	 * @param cellX  Proposed new cell x-location of hero 
	 * @param cellY  Proposed new cell y-location of hero
	 * @param hero   Reference to the Hero object
	 * @return       true if move worked, false otherwise
	 */
	public boolean attemptMove(int cellX, int cellY, Hero hero)
	{
		// TBD
		return false;
	}
	
	/**
	 * Draw all the cell tiles that make up the dungeon.
	 */
	public void draw()
	{		
		// TBD
	}
	
	/**
	 * Test out some of the methods in the Dungeon class
	 */
	public static void main(String [] args)
	{
		// Setup a fake 4 x 3 dungeon with 32 pixel tiles
		final int TILE_SIZE = 32;		
		Dungeon dungeon = new Dungeon(4, 3, TILE_SIZE);
		StdDraw.setCanvasSize(4 * TILE_SIZE, 3 * TILE_SIZE);
		StdDraw.setXscale(0, 4 * TILE_SIZE);
		StdDraw.setYscale(0, 3 * TILE_SIZE);
		
		// Create a dungeon like:
		//  W--W
		//  W---
		//  WDW-
		dungeon.set(0, 0, "W");
		dungeon.set(1, 0, "D");
		dungeon.set(2, 0, "W");
		dungeon.set(3, 0, "-");
		
		dungeon.set(0, 1, "W");
		dungeon.set(1, 1, "-");
		dungeon.set(2, 1, "-");
		dungeon.set(3, 1, "-");
		
		dungeon.set(0, 2, "W");
		dungeon.set(1, 2, "-");
		dungeon.set(2, 2, "-");
		dungeon.set(3, 2, "W");
		
		// Add one key and one gem in a random location
		dungeon.addKey();
		dungeon.addGem();
		
		// Draw the sample dungeon
		dungeon.draw();
	}	
}
