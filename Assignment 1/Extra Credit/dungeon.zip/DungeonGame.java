// Name        :
// Username    :
// Description :

public class DungeonGame
{
	public static void main(String [] args)
	{
		final int TILE_SIZE = 32;
		
		// TBD		
	}	
}
