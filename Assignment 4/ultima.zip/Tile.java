/*************************************************************************
 * Name        :  
 * Username    : 
 * Description :  
 *************************************************************************/
public class Tile 
{
	// Test method
	public static void main(String [] args)
	{
		final int SIZE 		= 16;
		final int WIDTH 	= 7;
		final int HEIGHT 	= 2;
		
		StdDraw.setCanvasSize(WIDTH * SIZE, HEIGHT * SIZE);
		StdDraw.setXscale(0.0, WIDTH * SIZE);
		StdDraw.setYscale(0.0, HEIGHT * SIZE);

		String [] codes = {"B", "L", "W", "F", "G", "M", "S"};
		for (int i = 0; i < WIDTH; i++)
		{
			for (int j = 0; j < HEIGHT; j++)
			{
				Tile tile = new Tile(codes[i]);
				if ((i + j) % 2 == 0)
					tile.setLit(true);
				System.out.printf("%d %d : lit %s\topaque %s\tpassable %s\n", 
						           i, j, tile.getLit(), tile.isOpaque(), tile.isPassable()); 
				tile.draw(i, j);
			}
		}		
	}	
}
