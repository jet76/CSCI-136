/*************************************************************************
 * Name        :  
 * Username    : 
 * Description :  
 *************************************************************************/

public class World
{
	// Test method	
	public static void main(String [] args)
	{		
		World world = new World(args[0]);
		world.draw();		
	}	
}
