/*************************************************************************
 * Name        :  
 * Username    : 
 * Description :  
 *************************************************************************/
public class Avatar 
{
	// Test method
	public static void main(String [] args)
	{
		Avatar avatar = new Avatar(5, 5);
		System.out.printf("%d %d %.1f\n", avatar.getX(), avatar.getY(), avatar.getTorchRadius());		
		avatar.setLocation(1, 4);
		System.out.printf("%d %d %.1f\n", avatar.getX(), avatar.getY(), avatar.getTorchRadius());
		avatar.increaseTorch();
		System.out.printf("%d %d %.1f\n", avatar.getX(), avatar.getY(), avatar.getTorchRadius());
		for (int i = 0; i < 6; i++)
		{
			avatar.decreaseTorch();
			System.out.printf("%d %d %.1f\n", avatar.getX(), avatar.getY(), avatar.getTorchRadius());
		}	
	}
}
